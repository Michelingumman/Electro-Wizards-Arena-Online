import { Card, PlayerHand } from '../types/game';
import { CARD_POOL } from '../config/cards/index';

const LEGENDARY_CARDS = CARD_POOL.filter(card => card.isLegendary);

export function generateInitialHand(): PlayerHand {
  const hand: Card[] = [];
  const stats = {
    common: 0,
    rare: 0,
    epic: 0,
    legendary: 0,
    total: 0
  };

  while (hand.length < 4) {
    const card = drawCard();
    hand.push(card);
    if (card.rarity) {
      stats[card.rarity.toLowerCase() as keyof typeof stats]++;
      stats.total++;
    }
  }

  return { cards: hand, stats };
}

export function drawCard(): Card {
  const pool = CARD_POOL;
  const card = pool[Math.floor(Math.random() * pool.length)];
  
  return {
    ...card,
    id: `${card.id}-${Math.random().toString(36).substr(2, 9)}`
  };
}

export function drawLegendaryCard(): Card {
  const card = LEGENDARY_CARDS[Math.floor(Math.random() * LEGENDARY_CARDS.length)];
  return {
    ...card,
    id: `${card.id}-${Math.random().toString(36).substr(2, 9)}`
  };
}